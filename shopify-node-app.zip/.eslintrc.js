module.exports = {
    "extends": "airbnb-base",
    "plugins": [
        "import"
    ]
};