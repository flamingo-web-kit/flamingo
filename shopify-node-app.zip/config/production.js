module.exports = {
  APP_URI: 'https://excellent-zoo-236414.appspot.com',
};
