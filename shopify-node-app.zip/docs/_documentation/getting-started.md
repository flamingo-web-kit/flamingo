---
title:  "Getting Started"
handle: "getting-started"
category: "getting-started"
---

### Introduction
This Getting Started section has been written in a tutorial format so that it can be understood by everyone of all skill levels.
That being said a prior knowledge of the terminal and javascript will be required. If you have any questions at all don't hesitate to raise an issue on Github.

This tutorial makes the assumption that you are using a unix based operating system (Mac/Linux).
